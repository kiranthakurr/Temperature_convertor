
import 'dart:ui';

var backgroundColor_hot = const Color(0xfff69d7a);
var backgroundColor_cold = const Color(0xff87ceeb);
var backgroundColor_med = const Color(0xfff8c964);